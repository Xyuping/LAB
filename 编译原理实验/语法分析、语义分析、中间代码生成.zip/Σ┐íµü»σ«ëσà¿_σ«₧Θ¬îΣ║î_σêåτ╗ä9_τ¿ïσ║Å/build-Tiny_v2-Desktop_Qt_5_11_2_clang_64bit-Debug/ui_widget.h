/********************************************************************************
** Form generated from reading UI file 'widget.ui'
**
** Created by: Qt User Interface Compiler version 5.11.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WIDGET_H
#define UI_WIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCommandLinkButton>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPlainTextEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QTextBrowser>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Widget
{
public:
    QPushButton *pushButton;
    QPushButton *save;
    QCommandLinkButton *commandLinkButton;
    QPlainTextEdit *input;
    QTabWidget *tabWidget;
    QWidget *tab;
    QTextBrowser *output_scan;
    QWidget *tab_2;
    QTextBrowser *output_parse;
    QWidget *widget;
    QTextBrowser *output_analyze;
    QWidget *tab_3;
    QTextBrowser *output_cegn;
    QLabel *label;
    QPushButton *new_2;
    QLabel *label_2;

    void setupUi(QWidget *Widget)
    {
        if (Widget->objectName().isEmpty())
            Widget->setObjectName(QStringLiteral("Widget"));
        Widget->resize(861, 650);
        pushButton = new QPushButton(Widget);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(340, 330, 111, 41));
        QFont font;
        font.setPointSize(20);
        pushButton->setFont(font);
        pushButton->setCheckable(true);
        save = new QPushButton(Widget);
        save->setObjectName(QStringLiteral("save"));
        save->setGeometry(QRect(340, 390, 111, 41));
        save->setFont(font);
        save->setCheckable(true);
        commandLinkButton = new QCommandLinkButton(Widget);
        commandLinkButton->setObjectName(QStringLiteral("commandLinkButton"));
        commandLinkButton->setGeometry(QRect(350, 460, 111, 41));
        QFont font1;
        font1.setPointSize(23);
        commandLinkButton->setFont(font1);
        commandLinkButton->setIconSize(QSize(32, 20));
        commandLinkButton->setCheckable(true);
        input = new QPlainTextEdit(Widget);
        input->setObjectName(QStringLiteral("input"));
        input->setGeometry(QRect(10, 100, 321, 491));
        tabWidget = new QTabWidget(Widget);
        tabWidget->setObjectName(QStringLiteral("tabWidget"));
        tabWidget->setGeometry(QRect(480, 90, 331, 511));
        tabWidget->setIconSize(QSize(16, 16));
        tab = new QWidget();
        tab->setObjectName(QStringLiteral("tab"));
        output_scan = new QTextBrowser(tab);
        output_scan->setObjectName(QStringLiteral("output_scan"));
        output_scan->setGeometry(QRect(0, 0, 331, 501));
        tabWidget->addTab(tab, QString());
        tab_2 = new QWidget();
        tab_2->setObjectName(QStringLiteral("tab_2"));
        output_parse = new QTextBrowser(tab_2);
        output_parse->setObjectName(QStringLiteral("output_parse"));
        output_parse->setGeometry(QRect(0, 0, 331, 471));
        tabWidget->addTab(tab_2, QString());
        widget = new QWidget();
        widget->setObjectName(QStringLiteral("widget"));
        output_analyze = new QTextBrowser(widget);
        output_analyze->setObjectName(QStringLiteral("output_analyze"));
        output_analyze->setGeometry(QRect(0, 0, 331, 481));
        tabWidget->addTab(widget, QString());
        tab_3 = new QWidget();
        tab_3->setObjectName(QStringLiteral("tab_3"));
        output_cegn = new QTextBrowser(tab_3);
        output_cegn->setObjectName(QStringLiteral("output_cegn"));
        output_cegn->setGeometry(QRect(0, 0, 331, 481));
        tabWidget->addTab(tab_3, QString());
        label = new QLabel(Widget);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(120, 50, 101, 31));
        QFont font2;
        font2.setPointSize(31);
        label->setFont(font2);
        new_2 = new QPushButton(Widget);
        new_2->setObjectName(QStringLiteral("new_2"));
        new_2->setGeometry(QRect(340, 270, 111, 41));
        new_2->setFont(font);
        new_2->setCheckable(true);
        label_2 = new QLabel(Widget);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(570, 40, 171, 41));
        label_2->setFont(font2);

        retranslateUi(Widget);

        tabWidget->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(Widget);
    } // setupUi

    void retranslateUi(QWidget *Widget)
    {
        Widget->setWindowTitle(QApplication::translate("Widget", "Widget", nullptr));
        pushButton->setText(QApplication::translate("Widget", " \346\211\223\345\274\200\346\226\207\344\273\266", nullptr));
        save->setText(QApplication::translate("Widget", "\344\277\235\345\255\230\346\226\207\344\273\266", nullptr));
        commandLinkButton->setText(QApplication::translate("Widget", "  \347\274\226\350\257\221", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab), QApplication::translate("Widget", "\350\257\215\346\263\225\345\210\206\346\236\220", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_2), QApplication::translate("Widget", " \350\257\255\346\263\225\345\210\206\346\236\220", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(widget), QApplication::translate("Widget", "\350\257\255\344\271\211\345\210\206\346\236\220", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_3), QApplication::translate("Widget", "\344\270\255\351\227\264\344\273\243\347\240\201", nullptr));
        label->setText(QApplication::translate("Widget", "\346\272\220\344\273\243\347\240\201", nullptr));
        new_2->setText(QApplication::translate("Widget", " \346\226\260\345\273\272", nullptr));
        label_2->setText(QApplication::translate("Widget", " \347\273\223\346\236\234\350\276\223\345\207\272", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Widget: public Ui_Widget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WIDGET_H
