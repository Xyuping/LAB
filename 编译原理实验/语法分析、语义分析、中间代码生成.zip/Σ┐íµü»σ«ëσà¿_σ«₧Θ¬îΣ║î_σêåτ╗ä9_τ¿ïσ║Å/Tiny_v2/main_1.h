#ifndef MAIN_1_H
#define MAIN_1_H
#include<string>
using namespace std;

int main_1(char*);

#endif // MAIN_1_H
