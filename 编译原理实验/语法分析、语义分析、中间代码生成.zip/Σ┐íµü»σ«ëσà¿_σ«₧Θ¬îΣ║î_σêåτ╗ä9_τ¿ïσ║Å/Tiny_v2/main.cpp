#include "widget.h"
#include <QApplication>
#include <QPushButton>
#include <QFile>
#include <QTextStream>
#include <QTextCodec>
#include <QDebug>
#include <QFileDialog>
#include<main_1.h>
#include<iostream>
//#pragma execution_character_set("utf-8")

using namespace std;

int main(int argc, char *argv[])
{
   QTextCodec *codec = QTextCodec::codecForName("Unicode");
   // QTextCodec::setCodecForTr(codec);
   QTextCodec::setCodecForLocale(codec);
   // QTextCodec::setCodecForCStrings(codec);

    QApplication a(argc, argv);
    Widget w;
    w.show();
    return a.exec();
}
