/****************************************************/
/* File: parse.c                                    */
/* The parser implementation for the TINY compiler  */
/* Compiler Construction: Principles and Practice   */
/* Kenneth C. Louden                                */
/****************************************************/
#include "GLOBALS.H"
#include "UTIL.H"
#include "SCAN.H"
#include "PARSE.H"

static TokenType token; /* holds current token */

                        /* function prototypes for recursive calls */
static TreeNode * program(void);
//static void declarations(void);
static TreeNode * declarations(void);
/*声明语句定义*/
static TreeNode *decl(void);
static TreeNode *type_specifier(void);
static TreeNode * varlist(ExpType);

static TreeNode * stmt_sequence(void);
static TreeNode * statement(void);
static TreeNode * while_stmt(void);
static TreeNode * if_stmt(void);
static TreeNode * repeat_stmt(void);
static TreeNode * assign_stmt(void);
static TreeNode * read_stmt(void);
static TreeNode * write_stmt(void);
static TreeNode * logical_or_exp(void);
static TreeNode * logical_and_exp(void);
static TreeNode * logical_not_exp(void);
static TreeNode * exp(void);
static TreeNode * simple_exp(void);
static TreeNode * term(void);
static TreeNode * factor(void);

static void syntaxError(char * message)
{
    fprintf(listing, "\n>>> ");
    fprintf(listing, "Syntax error at line %d: %s", lineno, message);
    Error = TRUE;
}

static void match(TokenType expected)
{
    if (token == expected)
    {

        token = getToken();
    }
    else {
        syntaxError("unexpected token -> ");
        printToken(token, tokenString);
        fprintf(listing, "      ");
    }
}

//stmt-sequence	-> statement [ ; stmt-sequence ]
TreeNode * stmt_sequence(void)
{
    TreeNode * t = statement();
    TreeNode * p = t;
    while ((token != ENDFILE) && (token != TK_END) &&
        (token != TK_ELSE) && (token != TK_UNTIL))
    {
        TreeNode * q;
        match(TK_SEMICOLON);                               //WY
        q = statement();
        if (q != NULL) {
            if (t == NULL) t = p = q;
            else /* now p cannot be NULL either */
            {
                p->sibling = q;
                p = q;
            }
        }
    }
    return t;
}
//7statement	-> if-stmt | repeat-stmt | assign-stmt | read-stmt | write-stmt | while-stmt
TreeNode * statement(void)
{
    TreeNode * t = NULL;
    switch (token) {
    case TK_IF: t = if_stmt(); break;
    case TK_REPEAT: t = repeat_stmt(); break;
    case ID: t = assign_stmt(); break;
    case TK_READ: t = read_stmt(); break;
    case TK_WRITE: t = write_stmt(); break;
    case TK_WHILE: t = while_stmt(); break;
    default: syntaxError("unexpected token -> ");
        printToken(token, tokenString);
        token = getToken();
        break;
    } /* end case */
    return t;
}

//while-stmt -> while logical-or-exp do stmt-sequence end
TreeNode * while_stmt(void)
{
    TreeNode * t = newStmtNode(WhileK);
    match(TK_WHILE);
    if (t != NULL) t->child[0] = logical_or_exp();
    match(TK_DO);
    if (t != NULL) t->child[1] = stmt_sequence();
    match(TK_END);
    return t;
}

//if-stmt -> if  logical-or-exp then stmt-sequence [else stmt-sequence] end
TreeNode * if_stmt(void)
{
    TreeNode * t = newStmtNode(IfK);
    match(TK_IF);
    if (t != NULL) t->child[0] = logical_or_exp();
    match(TK_THEN);
    if (t != NULL) t->child[1] = stmt_sequence();
    if (token == TK_ELSE) {
        match(TK_ELSE);
        if (t != NULL) t->child[2] = stmt_sequence();
    }
    match(TK_END);
    return t;
}

//repeat-stmt	-> repeat stmt-sequence until logical-or-exp
TreeNode * repeat_stmt(void)
{
    TreeNode * t = newStmtNode(RepeatK);
    match(TK_REPEAT);
    if (t != NULL) t->child[0] = stmt_sequence();
    match(TK_UNTIL);
    if (t != NULL) t->child[1] = logical_or_exp();
    return t;
}

//assign-stmt	-> identifier := logical-or-exp
TreeNode * assign_stmt(void)
{
    TreeNode * t = newStmtNode(AssignK);
    if ((t != NULL) && (token == ID))
        t->attr.name = copyString(tokenString);
    match(ID);
    match(TK_ASSIGN);                            //符号错误
    if (t != NULL) t->child[0] = logical_or_exp();
    return t;
}

//read-stmt	-> read identifier
TreeNode * read_stmt(void)
{
    TreeNode * t = newStmtNode(ReadK);
    match(TK_READ);
    if ((t != NULL) && (token == ID))
        t->attr.name = copyString(tokenString);
    match(ID);
    return t;
}

//write-stmt	-> write logical-or-exp
TreeNode * write_stmt(void)
{
    TreeNode * t = newStmtNode(WriteK);
    match(TK_WRITE);
    if (t != NULL) t->child[0] = logical_or_exp();
    return t;
}

//logical-or-exp	-> logical-and-exp [ or logical-or-exp ]
TreeNode * logical_or_exp(void)
{
    TreeNode* t = logical_and_exp();
    if (token == TK_OR) {

        TreeNode * p = newExpNode(OpK);
        if (p != NULL) {
            p->child[0] = t;
            p->attr.op = token;
            t = p;
        }
        match(TK_OR);
        if (t != NULL)
            t->child[1] = logical_and_exp();
    }
    return t;
}

//logical-and-exp -> comparison-exp [ and logical-and-exp]
TreeNode * logical_and_exp(void)
{
    TreeNode* t = logical_not_exp();
    if (token == TK_AND) {

        TreeNode * p = newExpNode(OpK);
        if (p != NULL) {
            p->child[0] = t;
            p->attr.op = token;
            t = p;
        }
        match(TK_AND);
        if (t != NULL)
            t->child[1] = logical_not_exp();
    }
    return t;
}

TreeNode * logical_not_exp(void)
{
    TreeNode * t = NULL;
    if (token == TK_NOT) {
        t = newExpNode(OpK);
        t->attr.op = token;
        match(TK_NOT);
    }
    TreeNode * p = exp();
    if (t != NULL)
        t->child[0] = p;
    else
        t = p;

    return t;
}

//comparison-exp -> add-exp [ comparison-op comparison-exp ]
TreeNode * exp(void)
{
    TreeNode * t = simple_exp();
    //comparison-op  -> < | = | > | >= | <=
    if ((token == TK_LSS) || (token == TK_EQU)|| (token == TK_GTR)|| (token == TK_LEQ)|| (token == TK_GEQ)) {
        TreeNode * p = newExpNode(OpK);
        if (p != NULL) {
            p->child[0] = t;
            p->attr.op = token;
            t = p;
        }
        match(token);
        if (t != NULL)
            t->child[1] = simple_exp();
    }
    return t;
}

//add-exp	-> mul-exp [ addop add-exp ]
TreeNode * simple_exp(void)
{
    TreeNode * t = term();
    //addop  -> + | -
    while ((token == TK_ADD) || (token == TK_SUB))
    {
        TreeNode * p = newExpNode(OpK);
        if (p != NULL) {
            p->child[0] = t;
            p->attr.op = token;
            t = p;
            match(token);
            t->child[1] = term();
        }
    }
    return t;
}

//mul-exp	-> factor [ mulop mul-exp ]
TreeNode * term(void)
{
    TreeNode * t = factor();
    //mulop  -> * | /
    while ((token == TK_MUL) || (token == TK_DIV))
    {
        TreeNode * p = newExpNode(OpK);
        if (p != NULL) {
            p->child[0] = t;
            p->attr.op = token;
            t = p;
            match(token);
            p->child[1] = factor();
        }
    }
    return t;
}

//factor  -> number | string | identifier | true | false| ( logical-or-exp )
TreeNode * factor(void)
{
    TreeNode * t = NULL;
    switch (token) {
    case NUM:
        t = newExpNode(ConstK);
        if ((t != NULL) && (token == NUM))
            t->attr.val = atoi(tokenString);
        match(NUM);
        break;
    case STR:
        t = newExpNode(STRK);
        if ((t != NULL) && (token == STR))
            t->attr.name = copyString(tokenString);
        match(STR);
        break;
    case ID:
        t = newExpNode(IdK);
        if ((t != NULL) && (token == ID))
            t->attr.name = copyString(tokenString);
        match(ID);
        break;
    case TK_TRUE:
        t = newExpNode(TK);
        if ((t != NULL) && (token == TK_TRUE))
            t->attr.name = copyString(tokenString);
        match(TK_TRUE);
        break;
    case TK_FALSE:
        t = newExpNode(FK);
        if ((t != NULL) && (token == TK_FALSE))
            t->attr.name = copyString(tokenString);
        match(TK_FALSE);
        break;
    case TK_LP:
        match(TK_LP);
        t = exp();
        match(TK_RP);
        break;
    default:
        syntaxError("unexpected token -> ");
        printToken(token, tokenString);
        token = getToken();
        break;
    }
    return t;
}

/*
declarations -> decl ; declarations |ε
decl->type - specifier varlist
type - specifier -> int | bool | string
varlist->identifier[, varlist]
*/
//增加新的声明语句类型后的递归构造语法树
//declarations -> decl ; declarations |ε
TreeNode * declarations(void)
{
    TreeNode * t = decl();
    match(TK_SEMICOLON);
    TreeNode * p = t;
    while ((token != ENDFILE) && (token != TK_END))
    {
        TreeNode * q = NULL;
        q = decl();
        if (q != NULL) {
            if (t == NULL) t = p = q;
            else /* now p cannot be NULL either */
            {
                p->sibling = q;
                p = q;
            }
            match(TK_SEMICOLON);
        }
        else {
            break;
        }
    }
    return t;
}
/*decl -> type-specifier varlist*/
TreeNode * decl(void)
{

    TreeNode * t = type_specifier();
    if (t != NULL) {
        ExpType t_type_tmp = t->type;
        t->child[0] = varlist(t_type_tmp);
    }
    return t;
}
/*type-specifier -> int | bool | string*/
TreeNode * type_specifier(void)
{
    TreeNode * t = NULL;
    switch (token)
    {
    case TK_INT:
        t = newDefineNode(IntD);
        t->attr.name = "int";
        t->type = Integer;
        match(TK_INT);
        break;
    case TK_BOOL:
        t = newDefineNode(BoolD);
        t->attr.name = "bool";
        t->type = Boolean;
        match(TK_BOOL);
        break;
    case TK_STRING:
        t = newDefineNode(StringD);
        t->attr.name = "string";
        t->type = String;
        match(TK_STRING);
        break;
    default:
        break;
    }
    return t;
}
/*varlist -> identifier [ , varlist ]*/
TreeNode * varlist(ExpType t_type)
{
    TreeNode * t = NULL;
    if (token == ID)
    {
        t = newExpNode(IdK);
        t->attr.name = copyString(tokenString);
        t->type = t_type;
        match(ID);
    }

    TreeNode * p = t;

    while ((token == TK_COMMA) && (token != ENDFILE) && (token != TK_END))
    {
        TreeNode * q;
        match(TK_COMMA);
        q = newExpNode(IdK);
        q->attr.name = copyString(tokenString);
        t->type = t_type;
        match(ID);
        if (q != NULL) {
            if (t == NULL) t = p = q;
            else
            {
                p->sibling = q;
                p = q;
            }
        }
    }
    return t;
}



//1program -> declarations stmt-sequence
TreeNode* program(void) {
    TreeNode * t = declarations();
    TreeNode * t_tmp = t;
    while (t_tmp->sibling != NULL)
        t_tmp = t_tmp->sibling;
    if (t_tmp != NULL) t_tmp->sibling = stmt_sequence();
    t_tmp = NULL;
    return t;	// 调用stmt_sequence()分析语句列表
                            // stmt_sequence()的返回值就是整个
                            // 程序的语法树（增加了声明部分）
}


/****************************************/
/* the primary function of the parser   */
/****************************************/
/* Function parse returns the newly
* constructed syntax tree
*/
TreeNode * parse(void)
{
    TreeNode * t;
    token = getToken();       // token
    t=program();
    //t = stmt_sequence();
    if (token != ENDFILE)
        syntaxError("Code ends before file\n");
    return t;
}
