/****************************************************/
/* File: globals.h                                  */
/* Global types and vars for TINY compiler          */
/* must come before other include files             */
/* Compiler Construction: Principles and Practice   */
/* Kenneth C. Louden                                */
/****************************************************/

#ifndef GLOBALS_H_
#define GLOBALS_H_

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

#ifndef FALSE
#define FALSE 0
#endif

#ifndef TRUE
#define TRUE 1
#endif

/* MAXRESERVED = the number of reserved words */
#define MAXRESERVED 18

typedef enum
/* book-keeping tokens */
{
    ENDFILE, ERROR_1, ERROR, ERROR_2, ERROR_3,ERROR_4,ERROR_5,
    TK_IF, TK_THEN, TK_ELSE, TK_END, TK_REPEAT, TK_UNTIL, TK_READ, TK_WRITE,
    TK_TRUE, TK_FALSE, TK_OR, TK_AND, TK_NOT, TK_INT, TK_BOOL, TK_STRING, TK_WHILE, TK_DO,
    ID, NUM,STR,
    TK_ASSIGN, TK_EQU, TK_LSS, TK_ADD, TK_SUB, TK_MUL, TK_DIV, TK_LP, TK_RP, SEMI, TK_COMMA, TK_SEMICOLON, TK_GTR, TK_LEQ, TK_GEQ
} TokenType;

extern FILE* source; /* source code text file */
extern FILE* listing; /* listing output text file */
extern FILE* code; /* code text file for TM simulator */

extern int lineno; /* source line number for listing */

                   /**************************************************/
                   /***********   Syntax tree for parsing ************/
                   /**************************************************/

typedef enum { StmtK, ExpK, Definek} NodeKind;//”Ôæ‰¿‡–Õ£¨±Ì¥Ô Ω¿‡–Õ£¨…˘√˜¿‡–Õ
typedef enum { IfK, RepeatK, AssignK, ReadK, WriteK,WhileK } StmtKind;
typedef enum { OpK, ConstK, IdK,STRK,TK,FK } ExpKind;
typedef enum { IntD, BoolD, StringD } DefineKind;//‘ˆº”…˘√˜¿‡–Õ
/* ExpType is used for type checking */
typedef enum { Void, Integer, Boolean,String} ExpType;//‘ˆº”Sring

#define MAXCHILDREN 3

typedef struct treeNode
{
    struct treeNode * child[MAXCHILDREN];
    struct treeNode * sibling;
    int lineno;
    NodeKind nodekind;
    union { StmtKind stmt; ExpKind exp; DefineKind define;
    } kind;
    union {
        TokenType op;
        int val;
        char * name;
    } attr;
    ExpType type; /* for type checking of exps */
} TreeNode;

/**************************************************/
/***********   Flags for tracing       ************/
/**************************************************/

/* EchoSource = TRUE causes the source program to
* be echoed to the listing file with line numbers
* during parsing
*/
extern int EchoSource;

/* TraceScan = TRUE causes token information to be
* printed to the listing file as each token is
* recognized by the scanner
*/
extern int TraceScan;

/* TraceParse = TRUE causes the syntax tree to be
* printed to the listing file in linearized form
* (using indents for children)
*/
extern int TraceParse;

/* TraceAnalyze = TRUE causes symbol table inserts
* and lookups to be reported to the listing file
*/
extern int TraceAnalyze;

/* TraceCode = TRUE causes comments to be written
* to the TM code file as code is generated
*/
extern int TraceCode;

/* Error = TRUE prevents further passes if an error occurs */
extern int Error;
#endif
