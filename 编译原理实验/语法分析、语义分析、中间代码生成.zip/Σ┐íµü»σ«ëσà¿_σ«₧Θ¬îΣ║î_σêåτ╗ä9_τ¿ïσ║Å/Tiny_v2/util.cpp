/****************************************************/
/* File: util.c                                     */
/* Utility function implementation                  */
/* for the TINY compiler                            */
/* Compiler Construction: Principles and Practice   */
/* Kenneth C. Louden                                */
/****************************************************/

#include "GLOBALS.H"
#include "UTIL.H"

/* Procedure printToken prints a token
* and its lexeme to the listing file
*/
void printToken(TokenType token, const char* tokenString)
{
    switch (token)
    {
    case TK_IF:
    case TK_THEN:fprintf(listing, "(TK_THEN,then)\n"); break;
    case TK_ELSE:fprintf(listing, "(TK_ELSE,else)\n"); break;
    case TK_END:fprintf(listing, "(TK_END,end)\n"); break;
    case TK_REPEAT:fprintf(listing, "(TK_REPEAT,repeat)\n"); break;
    case TK_UNTIL:fprintf(listing, "(TK_UTIL,until)\n"); break;
    case TK_READ:fprintf(listing, "(TK_READ,read)\n"); break;
    case TK_WRITE:fprintf(listing, "(TK_WRITE,write)\n"); break;
    case TK_TRUE:fprintf(listing, "(TK_TRUE,true)\n"); break;
    case TK_FALSE:fprintf(listing, "(TK_FALSE,false)\n"); break;
    case TK_OR:fprintf(listing, "(TK_OR,or)\n"); break;
    case TK_AND:fprintf(listing, "(TK_AND,and)\n"); break;
    case TK_NOT:fprintf(listing, "(TK_NOT,not)\n"); break;
    case TK_INT:fprintf(listing, "(TK_INT,int)\n"); break;
    case TK_STRING:fprintf(listing, "(TK_STRING,string)\n"); break;
    case TK_WHILE:fprintf(listing, "(TK_WHILE,while)\n"); break;
    case TK_DO:fprintf(listing, "(TK_DO,do)\n"); break;
    case TK_BOOL:fprintf(listing, "(TK_BOOL,bool)\n"); break;
        fprintf(listing,
                "reserved word: %s\n", tokenString);
        break;
    case TK_ASSIGN: fprintf(listing, "(TK_ASSIGN,:=)\n"); break;
    case TK_LSS: fprintf(listing, "(TK_LSS,<)\n"); break;
    case TK_EQU: fprintf(listing, "(TK_EQU,=)\n"); break;
    case TK_LP: fprintf(listing, "(TK_LP,()\n"); break;
    case TK_RP: fprintf(listing, "(TK_RP,))\n"); break;
    case TK_SEMICOLON: fprintf(listing, "(TK_SEMICOLON,;)\n"); break;
    case TK_ADD: fprintf(listing, "(TK_ADD,+)\n"); break;
    case TK_SUB: fprintf(listing, "(TK_SUB,-)\n"); break;
    case TK_MUL: fprintf(listing, "(TK_MUL,*)\n"); break;
    case TK_DIV: fprintf(listing, "(TK_DIV,/)\n"); break;
    case TK_COMMA:fprintf(listing, "(TK_COMMA,,)\n"); break;
    case TK_GTR:fprintf(listing, "(TK_GTR,>)\n"); break;
    case TK_LEQ:fprintf(listing, "(TK_LEQ,<=)\n"); break;
    case TK_GEQ:fprintf(listing, "(TK_GEQ,>=)\n"); break;
    case ENDFILE: fprintf(listing, "(ENDFILE,EOF)\n"); break;
    case NUM:
        fprintf(listing,
                "(NUM,%s)\n", tokenString);
        break;
    case ID:
        fprintf(listing,
                "(ID,%s)\n", tokenString);
        break;
    case ERROR_1:
        fprintf(listing,"ERROR: := 缺少 = \n");
    case ERROR_2:
        fprintf(listing, "ERROR: string error, expected '\n");
        break;
    case ERROR_3:
        fprintf(listing, "ERROR: unexpected end of file found, expected }\n");
        break;
    case ERROR_4:
        fprintf(listing, "ERROR: must start with {\n",tokenString);
        break;
    case ERROR_5:
        fprintf(listing,"ERROR:unkonwn character %s\n",tokenString);
        break;
    case ERROR:
        fprintf(listing,
                "ERROR: %s\n", tokenString);
        break;
    case STR:
        fprintf(listing, "(STRING,%s)", tokenString);
        break;
    default: /* should never happen */
        fprintf(listing, "Unknown token: %d\n", token);
    }
}

TreeNode * newDefineNode(DefineKind kind)
{
    TreeNode * t = (TreeNode *)malloc(sizeof(TreeNode));
    int i;
    if (t == NULL)
        fprintf(listing, "Out of memory error at line %d\n", lineno);
    else {
        for (i = 0; i < MAXCHILDREN; i++) t->child[i] = NULL;
        t->sibling = NULL;
        t->nodekind = Definek;
        t->kind.define = kind;
        t->lineno = lineno;
    }
    return t;
}
/* Function newStmtNode creates a new statement
* node for syntax tree construction
*/
TreeNode * newStmtNode(StmtKind kind)
{
    TreeNode * t = (TreeNode *)malloc(sizeof(TreeNode));
    int i;
    if (t == NULL)
        fprintf(listing, "Out of memory error at line %d\n", lineno);
    else {
        for (i = 0; i<MAXCHILDREN; i++) t->child[i] = NULL;
        t->sibling = NULL;
        t->nodekind = StmtK;
        t->kind.stmt = kind;
        t->lineno = lineno;
    }
    return t;
}


/* Function newExpNode creates a new expression
* node for syntax tree construction
*/
TreeNode * newExpNode(ExpKind kind)
{
    TreeNode * t = (TreeNode *)malloc(sizeof(TreeNode));
    int i;
    if (t == NULL)
        fprintf(listing, "Out of memory error at line %d\n", lineno);
    else {
        for (i = 0; i<MAXCHILDREN; i++) t->child[i] = NULL;
        t->sibling = NULL;
        t->nodekind = ExpK;
        t->kind.exp = kind;
        t->lineno = lineno;
        t->type = Void;
    }
    return t;
}

/* Function copyString allocates and makes a new
* copy of an existing string
*/
char * copyString(char * s)
{
    int n;
    char * t;
    if (s == NULL) return NULL;
    n = strlen(s) + 1;
    t = (char *)malloc(n);
    if (t == NULL)
        fprintf(listing, "Out of memory error at line %d\n", lineno);
    else strcpy(t, s);
    return t;
}

/* Variable indentno is used by printTree to
* store current number of spaces to indent
*/
static int indentno = 0;

/* macros to increase/decrease indentation */
#define INDENT indentno+=2
#define UNINDENT indentno-=2

/* printSpaces indents by printing spaces */
static void printSpaces(void)
{
    int i;
    for (i = 0; i<indentno; i++)
        fprintf(listing, " ");
}

/* procedure printTree prints a syntax tree to the
* listing file using indentation to indicate subtrees
*/
void printTree(TreeNode * tree)
{
    int i;
    INDENT;
    while (tree != NULL) {
        printSpaces();
        if (tree->nodekind == StmtK)
        {
            switch (tree->kind.stmt) {
            case IfK:
                fprintf(listing, "If\n");
                break;
            case RepeatK:
                fprintf(listing, "Repeat\n");
                break;
            case AssignK:
                fprintf(listing, "Assign to: %s\n", tree->attr.name);
                break;
            case ReadK:
                fprintf(listing, "Read: %s\n", tree->attr.name);
                break;
            case WriteK:
                fprintf(listing, "Write\n");
                break;
            case WhileK:
                fprintf(listing, "While\n");
                break;
            default:
                fprintf(listing, "Unknown ExpNode kind\n");
                break;
            }
        }
        else if (tree->nodekind == ExpK)
        {
            switch (tree->kind.exp) {
            case OpK:
                fprintf(listing, "Op: ");
                printToken(tree->attr.op, "\0");
                break;
            case ConstK:
                fprintf(listing, "Const: %d\n", tree->attr.val);
                break;
            case IdK:
                fprintf(listing, "Id: %s\n", tree->attr.name);
                break;
            case TK:
                fprintf(listing, "Boolen: %s\n", tree->attr.name);
                break;
            case FK:
                fprintf(listing, "Boolen: %s\n", tree->attr.name);
                break;
            case STRK:
                fprintf(listing, "String: %s\n", tree->attr.name);
                break;
            default:
                fprintf(listing, "Unknown ExpNode kind\n");
                break;
            }
        }
        else if (tree->nodekind == Definek)
        {
            int  flag_tmp = 0;
            switch (tree->kind.define) {
            case IntD:
                fprintf(listing, "Int: %s\n", tree->attr.name);
                flag_tmp = 1;
                break;
            case StringD:
                fprintf(listing, "String: %s\n", tree->attr.name);
                flag_tmp = 1;
                break;
            case BoolD:
                fprintf(listing, "Bool: %s\n", tree->attr.name);
                flag_tmp = 1;
                break;
            default:
                flag_tmp = 0;
                fprintf(listing, "Unknown DefineKNode kind\n");
                break;
            }
            if (flag_tmp == 1)
            {

                //fprintf(listing, "%s\n", tree->attr.name);
                /*TreeNode *child_tmp = tree->child[0];
                while (child_tmp != NULL)
                {
                    fprintf(listing,"\t%s,", child_tmp->attr.name);
                    child_tmp =  child_tmp->sibling;
                }
                child_tmp = NULL;
                fprintf(listing,"\n");*/
            }
        }
        else fprintf(listing, "Unknown node kind\n");
        for (i = 0; i<MAXCHILDREN; i++)
            printTree(tree->child[i]);
        tree = tree->sibling;
    }
    UNINDENT;
}
