#include "widget.h"
#include "ui_widget.h"
#include <QApplication>
#include <QPushButton>
#include <QFile>
#include <QTextStream>
#include <QTextCodec>
#include <QDebug>
#include <QFileDialog>
#include<QTextBlock>
#include<QTextDocument>
#include<QMessageBox>
#include<QInputDialog>
#include<main_1.h>
Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
}

Widget::~Widget()
{
    delete ui;
}

QString file_name="";
QString file_open="";



//打开源文件按钮触发事件
void Widget::on_pushButton_toggled(bool checked)
{

    file_open = QFileDialog::getOpenFileName(NULL,"标题",".","*.txt");
    if(file_open!=""){
        QString line = readFile(file_open,"");
        ui->input->clear();
        ui->input->insertPlainText(line);//输出到输入框中
        file_name=file_open;
    }

}

//保存按钮触发事件
void Widget::on_save_toggled(bool checked)
{

    if(file_name!=""){
        QStringList lines2;
        QFile file2( file_name );
        QTextDocument *document=Q_NULLPTR;
        QTextBlock textBlock;
        document=ui->input->document();
        for(textBlock=document->begin();textBlock!=document->end();textBlock=textBlock.next())
            lines2.append(textBlock.text());
        if ( file2.open( QIODevice::WriteOnly ) ) {//只读模式
            QTextStream stream( &file2 );
            for (auto it = lines2.begin(); it != lines2.end(); ++it )
                stream << *it << "\r\n";
            file2.close();
        }
        return;
    }
    //之前没选择过文件保存路径
    QString file_path = QFileDialog::getExistingDirectory(this,"请选择文件保存路径...","../");
    if(file_path.isEmpty())
    {

        return;
    }
    else
    {
        bool ok;
        QString text = QInputDialog::getText(this,tr("保存"),tr("请输入文件名:"),QLineEdit::Normal,tr(""),&ok);
        file_name=file_path+"_"+text+".txt";
    }

}


//读取文件
QString readFile(QString file_name,QString end){
    QFile file(file_name+end);
    QTextCodec::setCodecForLocale(QTextCodec::codecForName("gb2312"));//中文转码声明
    if ( file.open( QIODevice::ReadOnly ) ) {//只读方式
        QTextStream stream( &file );
        QString content;
        while ( !stream.atEnd() ) {
            content += stream.readAll(); // 一行一行读取，包括“/n”
        }
        file.close();
        return content;
    }
}


void Widget::on_commandLinkButton_clicked()
{
    //左边输入框为空
    if(ui->input->document()->begin().text()==""){
        QMessageBox::information(NULL, "错误", "请输入源代码", QMessageBox::Yes | QMessageBox::No, QMessageBox::Yes);
        return;
    }
    //文件未保存
    if(file_name==""){
        on_save_toggled(true);
    }
    else{
        char*  ch;
        QByteArray ba = file_name.toLatin1();
        ch=ba.data();
        main_1(ch);
        //读取相应输出文件到右侧
        ui->output_analyze->clear();
        ui->output_parse->clear();
        ui->output_scan->clear();
        ui->output_cegn->clear();
        ui->output_scan->insertPlainText(readFile(file_name.split(".")[0],"_scan.txt"));
        ui->output_parse->insertPlainText(readFile(file_name.split(".")[0],"_parse.txt"));
        ui->output_analyze->insertPlainText(readFile(file_name.split(".")[0],"_analyze.txt"));
        ui->output_cegn->insertPlainText(readFile(file_name.split(".")[0],".tm"));
    }
}

void Widget::on_new_2_clicked()
{
    ui->input->clear();
    ui->output_scan->clear();
    ui->output_cegn->clear();
    ui->output_parse->clear();
    ui->output_analyze->clear();
    file_name="";
    file_open="";
    on_save_toggled(true);
}
