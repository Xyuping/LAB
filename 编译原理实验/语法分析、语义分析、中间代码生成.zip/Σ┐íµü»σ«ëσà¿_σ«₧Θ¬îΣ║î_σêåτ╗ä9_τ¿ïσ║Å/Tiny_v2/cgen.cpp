/****************************************************/
/* File: cgen.c                                     */
/* The code generator implementation                */
/* for the TINY compiler                            */
/* (generates code for the TM machine)              */
/* Compiler Construction: Principles and Practice   */
/* Kenneth C. Louden                                */
/****************************************************/

#include "GLOBALS.H"
#include "SYMTAB.H"
#include "CODE.H"
#include "CGEN.H"
#include<stdlib.h>

/* tmpOffset is the memory offset for temps
It is decremented each time a temp is
stored, and incremeted when loaded again
*/
static int tmpOffset = 0;

/* prototype for internal recursive code generator */
static void cGen(TreeNode * tree);

/* Procedure genStmt generates code at a statement node */
static void genStmt(TreeNode * tree)
{
    TreeNode * p1, *p2, *p3;
    int savedLoc1, savedLoc2, currentLoc;
    int loc;
    switch (tree->kind.stmt) {

    case IfK:
        if (TraceCode) emitComment("-> if");
        p1 = tree->child[0];
        p2 = tree->child[1];
        p3 = tree->child[2];
        /* generate code for test expression */
        cGen(p1);
        savedLoc1 = emitSkip(1);
        emitComment("if: jump to else belongs here");
        /* recurse on then part */
        cGen(p2);
        savedLoc2 = emitSkip(1);
        emitComment("if: jump to end belongs here");
        currentLoc = emitSkip(0);
        emitBackup(savedLoc1);
        emitRM_Abs("JEQ", ac, currentLoc, "if: jmp to else");
        emitRestore();
        /* recurse on else part */
        cGen(p3);
        currentLoc = emitSkip(0);
        emitBackup(savedLoc2);
        emitRM_Abs("LDA", pc, currentLoc, "jmp to end");
        emitRestore();
        if (TraceCode)  emitComment("<- if");
        break; /* if_k */

    case RepeatK:
        if (TraceCode) emitComment("-> repeat");
        p1 = tree->child[0];
        p2 = tree->child[1];
        savedLoc1 = emitSkip(0);
        emitComment("repeat: jump after body comes back here");
        /* generate code for body */
        cGen(p1);
        /* generate code for test */
        cGen(p2);
        emitRM_Abs("JEQ", ac, savedLoc1, "repeat: jmp back to body");
        if (TraceCode)  emitComment("<- repeat");
        break; /* repeat */

    case AssignK:
        if (TraceCode) emitComment("-> assign");
        /* generate code for rhs */
        cGen(tree->child[0]);
        /* now store value */
        loc = st_lookup(tree->attr.name);
        emitRM("ST", ac, loc, gp, "assign: store value");
        if (TraceCode)  emitComment("<- assign");
        break; /* assign_k */

    case ReadK:
        emitRO("IN", ac, 0, 0, "read integer value");
        loc = st_lookup(tree->attr.name);
        emitRM("ST", ac, loc, gp, "read: store value");
        break;
    case WriteK:
        /* generate code for expression to write */
        cGen(tree->child[0]);
        /* now output it */
        emitRO("OUT", ac, 0, 0, "write ac");
        break;

    case WhileK:
        if (TraceCode) emitComment("-> while");
        p1 = tree->child[0];
        p2 = tree->child[1];
        /* generate code for test expression */
        savedLoc1 = emitSkip(0);
        emitComment("while: test in here");
        cGen(p1);
        savedLoc2 = emitSkip(1);
        cGen(p2);
        emitRM_Abs("LDA", pc, savedLoc1, "while jmp to end");
        currentLoc = emitSkip(0);
        emitBackup(savedLoc2);
        emitRM_Abs("JEQ", ac, currentLoc, "while: jmp back to body0");
        emitRestore();
        if (TraceCode)  emitComment("<- while");
        break; /* while */
    default:
        break;
    }
} /* genStmt */

  /* Procedure genExp generates code at an expression node */
static void genExp(TreeNode * tree)
{
    int loc;
    TreeNode * p1, *p2;
    switch (tree->kind.exp) {

    case ConstK:
        if (TraceCode) emitComment("-> Const");
        /* gen code to load integer constant using LDC */
        emitRM("LDC", ac, tree->attr.val, 0, "load const");
        if (TraceCode)  emitComment("<- Const");
        break; /* ConstK */

    case STRK:
        if (TraceCode) emitComment("-> Integer");
        /* gen code to load integer constant using LDC */
        emitRM("LDC", ac, tree->attr.val, 0, "load integer");
        if (TraceCode)  emitComment("<- Integer");
        break; /* STRK */

    case TK:
        if (TraceCode) emitComment("-> Boolean");
        /* gen code to load integer constant using LDC */
        emitRM("LDC", ac, tree->attr.val, 0, "load boolean");
        if (TraceCode)  emitComment("<- Boolean");
        break; /* TK */

    case FK:
        if (TraceCode) emitComment("-> Boolean");
        /* gen code to load integer constant using LDC */
        emitRM("LDC", ac, tree->attr.val, 0, "load boolean");
        if (TraceCode)  emitComment("<- Boolean");
        break; /* FK */

    case IdK:
        if (TraceCode) emitComment("-> Id");
        loc = st_lookup(tree->attr.name);
        emitRM("LD", ac, loc, gp, "load id value");
        if (TraceCode)  emitComment("<- Id");
        break; /* IdK */

    case OpK:
        if (TraceCode) emitComment("-> Op");
        p1 = tree->child[0];
        p2 = tree->child[1];
        /* gen code for ac = left arg */
        cGen(p1);
        /* gen code to push left operand */
        emitRM("ST", ac, tmpOffset--, mp, "op: push left");
        /* gen code for ac = right operand */
        cGen(p2);
        /* now load left operand */
        emitRM("LD", ac1, ++tmpOffset, mp, "op: load left");
        switch (tree->attr.op) {
        case TK_ADD:
            emitRO("ADD", ac, ac1, ac, "op +");
            break;
        case TK_SUB:
            emitRO("SUB", ac, ac1, ac, "op -");
            break;
        case TK_MUL:
            emitRO("MUL", ac, ac1, ac, "op *");
            break;
        case TK_DIV:
            emitRO("DIV", ac, ac1, ac, "op /");
            break;
        case TK_LSS:
            emitRO("SUB", ac, ac1, ac, "op <");
            emitRM("JLT", ac, 2, pc, "br if true");
            emitRM("LDC", ac, 0, ac, "false case");
            emitRM("LDA", pc, 1, pc, "unconditional jmp");
            emitRM("LDC", ac, 1, ac, "true case");
            break;
        case TK_EQU:
            emitRO("SUB", ac, ac1, ac, "op ==");
            emitRM("JEQ", ac, 2, pc, "br if true");
            emitRM("LDC", ac, 0, ac, "false case");
            emitRM("LDA", pc, 1, pc, "unconditional jmp");
            emitRM("LDC", ac, 1, ac, "true case");
            break;
        case TK_GTR:
            emitRO("SUB", ac, ac1, ac, "op >");
            emitRM("JGT", ac, 2, pc, "br if true");
            emitRM("LDC", ac, 0, ac, "false case");
            emitRM("LDA", pc, 1, pc, "unconditional jmp");
            emitRM("LDC", ac, 1, ac, "true case");
            break;
        case TK_LEQ:
            emitRO("SUB", ac, ac1, ac , "op <=");
            emitRM("JLE", ac, 2, pc, "br if true");
            emitRM("LDC", ac, 0, ac, "false case");
            emitRM("LDA", pc, 1, pc, "unconditional jmp");
            emitRM("LDC", ac, 1, ac, "true case");
            break;
        case TK_GEQ:
            emitRO("SUB", ac, ac1 , ac, "op >=");
            emitRM("JGE", ac, 2, pc, "br if true");
            emitRM("LDC", ac, 0, ac, "false case");
            emitRM("LDA", pc, 1, pc, "unconditional jmp");
            emitRM("LDC", ac, 1, ac, "true case");
            break;
        case TK_AND:
            emitComment("<- AND");
            emitRM("JEQ", ac, 6, pc, "left is false");
            emitRM("LDC", ac, 1, ac, "left is true");
            emitRM("JEQ", ac1, 2, pc, "right is false");
            emitRM("LDC", ac1, 1, ac1, "right is true");
            emitRM("LDA", pc, 1, pc, "conditional jmp");
            emitRM("LDC", ac, 0, ac, "right is false case");
            emitRM("LDA", pc, 1, pc, "jmp to avoid left_false");
            emitRM("LDC", ac, 0, ac, "left is false case");
            emitComment("-> AND");
            break;
        case TK_OR:
            emitComment("<- OR");
            emitRM("JNE", ac, 6, pc, "left is true");
            emitRM("LDC", ac, 0, ac, "false case");
            emitRM("JNE", ac1, 2, pc, "right if true");
            emitRM("LDC", ac1, 0, ac1, "false case");
            emitRM("LDA", pc, 1, pc, "unconditional jmp");
            emitRM("LDC", ac1, 1, ac1, "true case");
            emitRM("LDA", pc, 1, pc, " jmp to avoid left_true");
            emitRM("LDC", ac, 1, ac, "true case");
            emitComment("<- OR");
            break;


        default:
            emitComment("BUG: Unknown operator");
            break;
        } /* case op */
        if (TraceCode)  emitComment("<- Op");
        break; /* OpK */

    default:
        break;
    }
} /* genExp */

  /* Procedure cGen recursively generates code by
  * tree traversal
  */
static void cGen(TreeNode * tree)
{
    if (tree != NULL)
    {
        switch (tree->nodekind) {
        case StmtK:
            genStmt(tree);
            break;
        case ExpK:
            genExp(tree);
            break;
        default:
            break;
        }
        cGen(tree->sibling);
    }
}

/**********************************************/
/* the primary function of the code generator */
/**********************************************/
/* Procedure codeGen generates code to a code
* file by traversal of the syntax tree. The
* second parameter (codefile) is the file name
* of the code file, and is used to print the
* file name as a comment in the code file
*/
void codeGen(TreeNode * syntaxTree, char * codefile)
{
    char * s = (char *)malloc(strlen(codefile) + 7);
    strcpy(s, "File: ");
    strcat(s, codefile);
    emitComment("TINY Compilation to TM Code");
    emitComment(s);
    /* generate standard prelude */
    emitComment("Standard prelude:");
    emitRM("LD", mp, 0, ac, "load maxaddress from location 0");
    emitRM("ST", ac, 0, ac, "clear location 0");
    emitComment("End of standard prelude.");
    /* generate code for TINY program */
    cGen(syntaxTree);
    /* finish */
    emitComment("End of execution.");
    emitRO("HALT", 0, 0, 0, "");
}
