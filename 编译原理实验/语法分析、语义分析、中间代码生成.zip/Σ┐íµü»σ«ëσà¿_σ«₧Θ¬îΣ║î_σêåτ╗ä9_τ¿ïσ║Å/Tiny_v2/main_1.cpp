/****************************************************/
/* File: main.c                                     */
/* Main program for TINY compiler                   */
/* Compiler Construction: Principles and Practice   */
/* Kenneth C. Louden                                */
/****************************************************/

#include "GLOBALS.H"
#include<string>
using namespace std;
/* set NO_PARSE to TRUE to get a scanner-only compiler */
#define NO_PARSE FALSE
/* set NO_ANALYZE to TRUE to get a parser-only compiler */
#define NO_ANALYZE FALSE

/* set NO_CODE to TRUE to get a compiler that does not
* generate code
*/
#define NO_CODE FALSE

#include "UTIL.H"
#if NO_PARSE
#include "SCAN.H"
#else
#include "PARSE.H"
#if !NO_ANALYZE
#include "ANALYZE.H"
#if !NO_CODE
#include "CGEN.H"
#endif
#endif
#endif

/* allocate global variables */
int lineno = 0;
FILE * source;
FILE * listing;
FILE * code;

/* allocate and set tracing flags */
int EchoSource = TRUE;
int TraceScan = TRUE;
int TraceParse = TRUE;
int TraceAnalyze = TRUE;
int TraceCode = TRUE;

int Error = FALSE;

char* getFileName(char* filename,char* end){
    char * s;
    int fnlen = strcspn(filename, ".");
    s = (char *)calloc(fnlen + strlen(end), sizeof(char));
    strncpy(s, filename, fnlen);
    strcat(s, end);
    return s;
}

int main_1(char* filename)
{
    if(filename=="")
        return 0;

    TreeNode * syntaxTree;     //定义语法树

    char* pgm = filename;
    if (strchr(pgm, '.') == NULL)
        strcat(pgm, ".tny");
    source = fopen(pgm, "r");  //打开源代码文件
    if (source == NULL)
    {
        fprintf(stderr, "File %s not found\n", pgm);
        exit(1);
    }
    listing = stdout; /* send listing to screen */
    FILE *stream = freopen(getFileName(filename,"_scan.txt"), "w", stdout );

    fprintf(listing, "\nTINY COMPILATION: %s\n", pgm);
#if NO_PARSE                    //解析
    while (getToken() != ENDFILE);
    fflush(stdout);
    fclose(stream);
#else

    syntaxTree = parse(); // 语法分析生成语法树
    stream = freopen( getFileName(filename,"_parse.txt"), "w", stdout );
    if (TraceParse) {           // 判断语法树是否生成
        fprintf(listing, "\nSyntax tree:\n");
        printTree(syntaxTree);
    }
    fflush(stdout);
    fclose(stream);
#if !NO_ANALYZE             // 语义分析
    stream = freopen(getFileName(filename,"_analyze.txt") , "w", stdout );
    if (!Error)
    {
        if (TraceAnalyze) fprintf(listing, "\nBuilding Symbol Table...\n");
        buildSymtab(syntaxTree);
        if (TraceAnalyze) fprintf(listing, "\nChecking Types...\n");
        typeCheck(syntaxTree);
        if (TraceAnalyze) fprintf(listing, "\nType Checking Finished\n");
    }
    fflush(stdout);
    fclose(stream);


#if !NO_CODE               // 中间代码生成
    if (!Error)
    {
        char * codefile;
        int fnlen = strcspn(pgm, ".");   // 返回'.'在pgm 中的下标值， 即文件名长度
        codefile = (char *)calloc(fnlen + 4, sizeof(char));
        strncpy(codefile, pgm, fnlen);    // 从pgm中复制fnlen个字符给codefile
        strcat(codefile, ".tm");         // 字符串相接
        code = fopen(codefile, "w");
        if (code == NULL)
        {
            printf("Unable to open %s\n", codefile);
            exit(1);
        }
        codeGen(syntaxTree, codefile);   // 中间代码生成
        fclose(code);
    }
#endif
#endif
#endif
    fclose(source);
    //system("pause");
    return 0;
}
